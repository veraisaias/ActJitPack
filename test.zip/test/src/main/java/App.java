import org.apache.commons.math3.analysis.function.Subtract;
import org.apache.commons.math3.stat.descriptive.summary.Sum;

public class App {
    public static void main(String[] args) {
        Copyright copyright = new Copyright();
        System.out.println(copyright.getCopyright());
    }
}